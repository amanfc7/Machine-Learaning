import re
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from collections import Counter

# Replace with actual log file path
log_file_path = "custom_sim_ann_for_ds_2.log"

# Lists to store extracted data
iterations = []
temperatures = []
best_scores = []
elapsed_times = []
classifiers = []

# Regular expressions to extract data
iter_pattern = re.compile(r"t = (\d+), T = ([\d.]+)")
score_pattern = re.compile(r"Current best score: ([\d.]+) for the (\w+)")
elapsed_pattern = re.compile(r"Elapsed mins since start: ([\d.]+)")

# Read and parse log file
with open(log_file_path, "r") as file:
    for line in file:
        iter_match = iter_pattern.search(line)
        score_match = score_pattern.search(line)
        elapsed_match = elapsed_pattern.search(line)

        if iter_match:
            iterations.append(int(iter_match.group(1)))
            temperatures.append(float(iter_match.group(2)))

        if score_match:
            best_scores.append(float(score_match.group(1)))
            classifiers.append(score_match.group(2))

        if elapsed_match:
            elapsed_times.append(float(elapsed_match.group(1)))

# Ensure lists are same length
min_length = min(len(iterations), len(best_scores), len(temperatures), len(elapsed_times))
iterations = iterations[:min_length]
temperatures = temperatures[:min_length]
best_scores = best_scores[:min_length]
elapsed_times = elapsed_times[:min_length]
classifiers = classifiers[:min_length]

# Convert lists to numpy arrays for better plotting
iterations = np.array(iterations)
temperatures = np.array(temperatures)
best_scores = np.array(best_scores)
elapsed_times = np.array(elapsed_times)

# Set Seaborn style
sns.set_style("whitegrid")

# Plot 1: Best Score vs. Iteration (Performance Trend)
plt.figure(figsize=(8, 5))
sns.lineplot(x=iterations, y=best_scores, marker="o", color="b")
plt.xlabel("Iteration (t)")
plt.ylabel("Best Score")
plt.title("Performance Trend: Best Score vs. Iteration")
plt.savefig("custom_ds_2_0.png")
plt.show()

# Plot 2: Temperature vs. Iteration (Annealing Process)
plt.figure(figsize=(8, 5))
sns.lineplot(x=iterations, y=temperatures, marker="o", color="r")
plt.xlabel("Iteration (t)")
plt.ylabel("Temperature (T)")
plt.title("Annealing Process: Temperature vs. Iteration")
plt.savefig("custom_ds_2_1.png")
plt.show()

# Plot 3: Best Score Over Elapsed Time
plt.figure(figsize=(8, 5))
sns.lineplot(x=elapsed_times, y=best_scores, marker="o", color="g")
plt.xlabel("Elapsed Time (minutes)")
plt.ylabel("Best Score")
plt.title("Best Score Over Time")
plt.savefig("custom_ds_2_2.png")
plt.show()


# Count occurences of classifiers
classifier_counts = Counter(classifiers)


# Plot 4: Classifier Performance Comparison
plt.figure(figsize=(8, 5))
sns.barplot(x=list(classifier_counts.keys()), y=list(classifier_counts.values()), palette="viridis")
plt.xlabel("Classifier")
plt.ylabel("Frequency of Selection")
plt.title("Classifier Selection Frequency During Optimization")
plt.xticks(rotation=45)
plt.savefig("custom_ds_2_3.png")
plt.show()