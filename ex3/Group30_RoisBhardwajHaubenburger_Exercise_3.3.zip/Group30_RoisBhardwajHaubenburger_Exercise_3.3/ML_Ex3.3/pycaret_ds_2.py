from pycaret.classification import load_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Load your dataset (replace with actual path to your dataset)
data = pd.read_csv('congressional_voting_preprocessed.csv')  # Update with your dataset file path

# Assume that the last column is the target variable
features = data.drop('Class Name', axis=1)  # 'Class' is your target column
target = data['Class Name']

# Split into training and testing sets
train_features, test_features, train_target, test_target = train_test_split(features, target, test_size=0.25, random_state=42)

# Load the trained model from the pickle file
model = load_model('best_pipeline_for_ds_2')  

# Define the expected columns for the features based on the model
expected_columns = [f'feature_{i}' for i in range(1, 17)]  # 16 features as expected by the model

# Ensure the test features have the correct column names
test_features.columns = expected_columns  # Renaming the test columns to match

# Make predictions on the test set
predictions = model.predict(test_features)

# Evaluate the model's performance
accuracy = accuracy_score(test_target, predictions)
precision = precision_score(test_target, predictions)
recall = recall_score(test_target, predictions)
f1 = f1_score(test_target, predictions)
conf_matrix = confusion_matrix(test_target, predictions)


# Save evaluation scores to a text file
with open("pycaret_ds_2_results.txt", "w") as f:
    f.write(f"Accuracy: {accuracy:.4f}\n")
    f.write(f"Precision: {precision:.4f}\n")
    f.write(f"Recall: {recall:.4f}\n")
    f.write(f"F1 Score: {f1:.4f}\n\n")
    f.write("Classification Report:\n")
    f.write(classification_report(test_target, predictions))

# Plot confusion matrix and save it
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=["Democrat", "Republican"], yticklabels=["Democrat", "Republican"])
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')

# Save the plot as a PNG file
plt.savefig("pycaret_ds_2_plot.png")

# Show the plot
plt.show()
