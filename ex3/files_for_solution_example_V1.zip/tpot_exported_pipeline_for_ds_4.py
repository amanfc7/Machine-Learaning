import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report

import matplotlib.pyplot as plt
import seaborn as sns

# NOTE: Make sure that the outcome column is labeled 'target' in the data file
tpot_data = pd.read_csv('wine_preprocessed.csv', sep=',', dtype=np.float64)
features = tpot_data.drop('0', axis=1)
training_features, testing_features, training_target, testing_target = \
            train_test_split(features, tpot_data['0'], random_state=42)

# Average CV score on the training set was: 1.0
exported_pipeline = GradientBoostingClassifier(learning_rate=0.5, max_depth=4, max_features=0.45, min_samples_leaf=1, min_samples_split=8, n_estimators=100, subsample=1.0)
# Fix random state in exported estimator
if hasattr(exported_pipeline, 'random_state'):
    setattr(exported_pipeline, 'random_state', 42)

exported_pipeline.fit(training_features, training_target)
results = exported_pipeline.predict(testing_features)

# Calculate metrics
# Calculate metrics (for multiclass, use average='macro' or 'weighted')
accuracy = accuracy_score(testing_target, results)
precision = precision_score(testing_target, results, average="macro")  # or "weighted"
recall = recall_score(testing_target, results, average="macro")  # or "weighted"
f1 = f1_score(testing_target, results, average="macro")  # or "weighted"
conf_matrix = confusion_matrix(testing_target, results)


# Save metrics to a text file
with open("tpot_ds_4_results.txt", "w") as f:
    f.write(f"Accuracy: {accuracy:.4f}\n")
    f.write(f"Precision: {precision:.4f}\n")
    f.write(f"Recall: {recall:.4f}\n")
    f.write(f"F1 Score: {f1:.4f}\n\n")
    f.write("Classification Report:\n")
    f.write(classification_report(testing_target, results))

print("Metrics saved to 'tpot_ds_4_results.txt'")


# # Plot confusion matrix
plt.figure(figsize=(5,4))
sns.heatmap(conf_matrix, annot=True, fmt="d", cmap="Blues", xticklabels=["1", "2", "3"], yticklabels=["1", "2", "3"])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix (TPOT)")
plt.savefig("tpot_ds_4.png")
plt.show()