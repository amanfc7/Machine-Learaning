import numpy as np
import pandas as pd
from sklearn.feature_selection import SelectFwe, f_classif
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.svm import LinearSVC
from tpot.export_utils import set_param_recursive

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report

import matplotlib.pyplot as plt
import seaborn as sns

# NOTE: Make sure that the outcome column is labeled 'target' in the data file
tpot_data = pd.read_csv('dataset_60_waveform-5000.csv', sep=',', dtype=np.float64, header = None)
features = tpot_data.iloc[:, :-1]  
target = tpot_data.iloc[:, -1]   
training_features, testing_features, training_target, testing_target = \
            train_test_split(features, target, random_state=42)


# Average CV score on the training set was: 0.8703636849132176
exported_pipeline = make_pipeline(
    SelectFwe(score_func=f_classif, alpha=0.036000000000000004),
    LinearSVC(C=0.1, dual=True, loss="squared_hinge", penalty="l2", tol=0.1)
)
# Fix random state for all the steps in exported pipeline
set_param_recursive(exported_pipeline.steps, 'random_state', 42)

exported_pipeline.fit(training_features, training_target)
results = exported_pipeline.predict(testing_features)


# Calculate metrics
accuracy = accuracy_score(testing_target, results)
precision = precision_score(testing_target, results, average='weighted')
recall = recall_score(testing_target, results, average='weighted')
f1 = f1_score(testing_target, results, average='weighted')
conf_matrix = confusion_matrix(testing_target, results)

# Save metrics to a text file
with open("tpot_ds_3_results.txt", "w") as f:
    f.write(f"Accuracy: {accuracy:.4f}\n")
    f.write(f"Precision: {precision:.4f}\n")
    f.write(f"Recall: {recall:.4f}\n")
    f.write(f"F1 Score: {f1:.4f}\n\n")
    f.write("Classification Report:\n")
    f.write(classification_report(testing_target, results))

print("Metrics saved to 'tpot_ds_3_results.txt'")

# Confusion matrix
plt.figure(figsize=(6, 5))
sns.heatmap(conf_matrix, annot=True, fmt="d", cmap="Blues", xticklabels=["0", "1", "2"], yticklabels=["0", "1", "2"])
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix")
plt.show()